import 'package:flutter_wattvita/screens/signin_screen2.dart';

var id = SigninScreen2State.userid;

// Browser
// const String postReg = "http://localhost:5000/api/register/step1";
// String postReg2 = "http://localhost:5000/api/register/step2/$id";
// const profileData = "http://localhost:5000/api/me";
// const loginapi = "http://localhost:5000/api/login";
// const logoutapi = "http://localhost:5000/api/logout";

// Mobile

const String postReg = "http://192.168.1.11:5000/api/register/step1";
String postReg2 = "http://192.168.1.11:5000/api/register/step2/$id";
const profileData = "http://192.168.1.11:5000/api/me";
const loginapi = "http://192.168.1.11:5000/api/login";
const logoutapi = "http://192.168.1.11:5000/api/logout";
